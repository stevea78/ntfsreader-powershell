﻿/*
    The NtfsReader library.

    Copyright (C) 2008 Danny Couture

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    For the full text of the license see the "License.txt" file.

    This library is based on the work of Jeroen Kessels, Author of JkDefrag.
    http://www.kessels.com/Jkdefrag/

    Special thanks goes to him.

    Danny Couture
    Software Architect
*/
using Microsoft.Win32.SafeHandles;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.Runtime.InteropServices;

namespace System.IO.Filesystem.Ntfs
{
    public sealed partial class NtfsReader : IDisposable
    {

        private const ulong VIRTUALFRAGMENT = 18446744073709551615; // _UI64_MAX - 1 */
        private const uint ROOTDIRECTORY = 5;
        // private readonly byte[] BitmapMasks = new byte[] { 1, 2, 4, 8, 16, 32, 64, 128 };
        private SafeFileHandle volumeHandle;
        private DiskInfoWrapper diskInfo;
        private Node[] nodes;
        private Hashtable parentNodeSubFileCount = new Hashtable();
        private Hashtable parentNodeSubFileTotalSize = new Hashtable();
        private Hashtable parentNodeSubFolderCount = new Hashtable();
        private StandardInformation[] standardInformations;
        private Stream[][] streams;
        private DriveInfo driveInfo;
        private List<string> names = new List<string>();
        private RetrieveMode retrieveMode;
        private byte[] bitmapData;

        // preallocate a lot of space for the strings to avoid too much dictionary resizing
        // use ordinal comparison to improve performance
        // this will be deallocated once the MFT reading is finished
        Dictionary<string, int> nameIndex = new Dictionary<string, int>(128 * 1024, StringComparer.Ordinal);

        private enum RecordType : uint
        {
            File = 0x454c4946,  // 'FILE' in ASCII
        }

        private enum AttributeType : uint
        {
            AttributeInvalid = 0x00,         /* Not defined by Windows */
            AttributeStandardInformation = 0x10,
            AttributeAttributeList = 0x20,
            AttributeFileName = 0x30,
            AttributeObjectId = 0x40,
            AttributeSecurityDescriptor = 0x50,
            AttributeVolumeName = 0x60,
            AttributeVolumeInformation = 0x70,
            AttributeData = 0x80,
            AttributeIndexRoot = 0x90,
            AttributeIndexAllocation = 0xA0,
            AttributeBitmap = 0xB0,
            AttributeReparsePoint = 0xC0,         /* Reparse Point = Symbolic link */
            AttributeEAInformation = 0xD0,
            AttributeEA = 0xE0,
            AttributePropertySet = 0xF0,
            AttributeLoggedUtilityStream = 0x100,
        }

        /// <summary>
        /// Decode the RunLength value.
        /// </summary>
        private static unsafe long ProcessRunLength(byte* runData, uint runDataLength, int runLengthSize, ref uint index)
        {
            long runLength = 0;
            byte* runLengthBytes = (byte*)&runLength;
            for (int i = 0; i < runLengthSize; i++)
            {
                runLengthBytes[i] = runData[index];
                if (++index >= runDataLength)
                {
                    throw new Exception("Datarun is longer than buffer, the MFT may be corrupt.");
                }
            }

            return runLength;
        }

        /// <summary>
        /// Decode the RunOffset value.
        /// </summary>
        private static unsafe long ProcessRunOffset(byte* runData, uint runDataLength, int runOffsetSize, ref uint index)
        {
            long runOffset = 0;
            byte* runOffsetBytes = (byte*)&runOffset;

            int i;
            for (i = 0; i < runOffsetSize; i++)
            {
                runOffsetBytes[i] = runData[index];
                if (++index >= runDataLength)
                {
                    throw new Exception("Datarun is longer than buffer, the MFT may be corrupt.");
                }
            }

            // process negative values
            if (runOffsetBytes[i - 1] >= 0x80)
            {
                while (i < 8)
                {
                    runOffsetBytes[i++] = 0xFF;
                }
            }

            return runOffset;
        }

        /// <summary>
        /// Allocate or retrieve an existing index for the particular string.
        /// </summary>
        /// <remarks>
        /// In order to mimize memory usage, we reuse string as much as possible.
        /// </remarks>
        private int GetNameIndex(string name)
        {
            int existingIndex;
            if (this.nameIndex.TryGetValue(name, out existingIndex))
            {
                return existingIndex;
            }

            this.names.Add(name);
            this.nameIndex[name] = this.names.Count - 1;

            return this.names.Count - 1;
        }

        /// <summary>
        /// Get the string from our stringtable from the given index.
        /// </summary>
        private string GetNameFromIndex(int nameIndex)
        {
            return nameIndex == 0 ? null : this.names[nameIndex];
        }

        private Stream SearchStream(List<Stream> streams, AttributeType streamType)
        {
            // since the number of stream is usually small, we can afford O(n)
            foreach (Stream stream in streams)
            {
                if (stream.Type == streamType)
                {
                    return stream;
                }
            }

            return null;
        }

        private Stream SearchStream(List<Stream> streams, AttributeType streamType, int streamNameIndex)
        {
            // since the number of stream is usually small, we can afford O(n)
            foreach (Stream stream in streams)
            {
                if (stream.Type == streamType &&
                    stream.NameIndex == streamNameIndex)
                {
                    return stream;
                }
            }

            return null;
        }

        private unsafe void ReadFile(byte* buffer, int len, ulong absolutePosition)
        {
            this.ReadFile(buffer, (ulong)len, absolutePosition);
        }

        private unsafe void ReadFile(byte* buffer, uint len, ulong absolutePosition)
        {
            this.ReadFile(buffer, (ulong)len, absolutePosition);
        }

        private unsafe void ReadFile(byte* buffer, ulong len, ulong absolutePosition)
        {
            NativeOverlapped overlapped = new NativeOverlapped(absolutePosition);

            uint read;
            if (!ReadFile(this.volumeHandle, (IntPtr)buffer, (uint)len, out read, ref overlapped))
            {
                throw new Exception("Unable to read volume information");
            }

            if (read != (uint)len)
            {
                throw new Exception("Unable to read volume information");
            }
        }

        /// <summary>
        /// Read the next contiguous block of information on disk.
        /// </summary>
        private unsafe bool ReadNextChunk(
            byte* buffer,
            uint bufferSize,
            uint nodeIndex,
            int fragmentIndex,
            Stream dataStream,
            ref ulong blockStart,
            ref ulong blockEnd,
            ref ulong vcn,
            ref ulong realVcn)
        {
            blockStart = nodeIndex;
            blockEnd = blockStart + (bufferSize / this.diskInfo.BytesPerMftRecord);
            if (blockEnd > dataStream.Size * 8)
            {
                blockEnd = dataStream.Size * 8;
            }

            ulong u1 = 0;

            int fragmentCount = dataStream.Fragments.Count;
            while (fragmentIndex < fragmentCount)
            {
                Fragment fragment = dataStream.Fragments[fragmentIndex];

                /* Calculate Inode at the end of the fragment. */
                u1 = (realVcn + fragment.NextVcn - vcn) * this.diskInfo.BytesPerSector * this.diskInfo.SectorsPerCluster / this.diskInfo.BytesPerMftRecord;

                if (u1 > nodeIndex)
                {
                    break;
                }

                do
                {
                    if (fragment.Lcn != VIRTUALFRAGMENT)
                    {
                        realVcn = realVcn + fragment.NextVcn - vcn;
                    }

                    vcn = fragment.NextVcn;

                    if (++fragmentIndex >= fragmentCount)
                    {
                        break;
                    }
                }
                while (fragment.Lcn == VIRTUALFRAGMENT);
            }

            if (fragmentIndex >= fragmentCount)
            {
                return false;
            }

            if (blockEnd >= u1)
            {
                blockEnd = u1;
            }

            ulong position =
                ((dataStream.Fragments[fragmentIndex].Lcn - realVcn) * this.diskInfo.BytesPerSector *
                    this.diskInfo.SectorsPerCluster) + (blockStart * this.diskInfo.BytesPerMftRecord);

            this.ReadFile(buffer, (blockEnd - blockStart) * this.diskInfo.BytesPerMftRecord, position);

            return true;
        }

        /// <summary>
        /// Gather basic disk information we need to interpret data.
        /// </summary>
        private unsafe void InitializeDiskInfo()
        {
            byte[] volumeData = new byte[512];

            fixed (byte* ptr = volumeData)
            {
                this.ReadFile(ptr, volumeData.Length, 0);

                BootSector* bootSector = (BootSector*)ptr;

                if (bootSector->Signature != 0x202020205346544E)
                {
                    throw new Exception("This is not an NTFS disk.");
                }

                DiskInfoWrapper diskInfo = new DiskInfoWrapper();
                diskInfo.BytesPerSector = bootSector->BytesPerSector;
                diskInfo.SectorsPerCluster = bootSector->SectorsPerCluster;
                diskInfo.TotalSectors = bootSector->TotalSectors;
                diskInfo.MftStartLcn = bootSector->MftStartLcn;
                diskInfo.Mft2StartLcn = bootSector->Mft2StartLcn;
                diskInfo.ClustersPerMftRecord = bootSector->ClustersPerMftRecord;
                diskInfo.ClustersPerIndexRecord = bootSector->ClustersPerIndexRecord;

                if (bootSector->ClustersPerMftRecord >= 128)
                {
                    diskInfo.BytesPerMftRecord = 1UL << (byte)(256 - (byte)bootSector->ClustersPerMftRecord);
                }
                else
                {
                    diskInfo.BytesPerMftRecord = diskInfo.ClustersPerMftRecord * diskInfo.BytesPerSector * diskInfo.SectorsPerCluster;
                }

                diskInfo.BytesPerCluster = (ulong)diskInfo.BytesPerSector * (ulong)diskInfo.SectorsPerCluster;

                if (diskInfo.SectorsPerCluster > 0)
                {
                    diskInfo.TotalClusters = diskInfo.TotalSectors / diskInfo.SectorsPerCluster;
                }

                this.diskInfo = diskInfo;
            }
        }

        /// <summary>
        /// Used to check/adjust data before we begin to interpret it.
        /// </summary>
        private unsafe void FixupRawMftdata(byte* buffer, ulong len)
        {
            FileRecordHeader* ntfsFileRecordHeader = (FileRecordHeader*)buffer;

            if (ntfsFileRecordHeader->RecordHeader.Type != RecordType.File)
            {
                return;
            }

            ushort* wordBuffer = (ushort*)buffer;

            ushort* updateSequenceArray = (ushort*)(buffer + ntfsFileRecordHeader->RecordHeader.UsaOffset);
            uint increment = (uint)this.diskInfo.BytesPerSector / sizeof(ushort);

            uint index = increment - 1;

            for (int i = 1; i < ntfsFileRecordHeader->RecordHeader.UsaCount; i++)
            {
                /* Check if we are inside the buffer. */
                if (index * sizeof(ushort) >= len)
                {
                    throw new Exception("USA data indicates that data is missing, the MFT may be corrupt.");
                }

                // Check if the last 2 bytes of the sector contain the Update Sequence Number.
                if (wordBuffer[index] != updateSequenceArray[0])
                {
                    throw new Exception("USA fixup word is not equal to the Update Sequence Number, the MFT may be corrupt.");
                }

                /* Replace the last 2 bytes in the sector with the value from the Usa array. */
                wordBuffer[index] = updateSequenceArray[i];
                index = index + increment;
            }
        }

        /// <summary>
        /// Read the data that is specified in a RunData list from disk into memory,
        /// skipping the first Offset bytes.
        /// </summary>
        private unsafe byte[] ProcessNonResidentData(
            byte* runData,
            uint runDataLength,
            ulong offset,         /* Bytes to skip from begin of data. */
            ulong wantedLength) /* Number of bytes to read. */
        {
            /* Sanity check. */
            if (runData == null || runDataLength == 0)
            {
                throw new Exception("nothing to read");
            }

            if (wantedLength >= uint.MaxValue)
            {
                throw new Exception("too many bytes to read");
            }

            /* We have to round up the WantedLength to the nearest sector. For some
               reason or other Microsoft has decided that raw reading from disk can
               only be done by whole sector, even though ReadFile() accepts it's
               parameters in bytes. */
            if (wantedLength % this.diskInfo.BytesPerSector > 0)
            {
                wantedLength += this.diskInfo.BytesPerSector - (wantedLength % this.diskInfo.BytesPerSector);
            }

            /* Walk through the RunData and read the requested data from disk. */
            uint index = 0;
            long lcn = 0;
            long vcn = 0;

            byte[] buffer = new byte[wantedLength];

            fixed (byte* bufPtr = buffer)
            {
                while (runData[index] != 0)
                {
                    /* Decode the RunData and calculate the next Lcn. */
                    int runLengthSize = runData[index] & 0x0F;
                    int runOffsetSize = (runData[index] & 0xF0) >> 4;

                    if (++index >= runDataLength)
                    {
                        throw new Exception("Error: datarun is longer than buffer, the MFT may be corrupt.");
                    }

                    long runLength =
                        ProcessRunLength(runData, runDataLength, runLengthSize, ref index);

                    long runOffset =
                        ProcessRunOffset(runData, runDataLength, runOffsetSize, ref index);

                    // Ignore virtual extents.
                    if (runOffset == 0 || runLength == 0)
                    {
                        continue;
                    }

                    lcn += runOffset;
                    vcn += runLength;

                    /* Determine how many and which bytes we want to read. If we don't need
                       any bytes from this extent then loop. */
                    ulong extentVcn = (ulong)((vcn - runLength) * this.diskInfo.BytesPerSector * this.diskInfo.SectorsPerCluster);
                    ulong extentLcn = (ulong)(lcn * this.diskInfo.BytesPerSector * this.diskInfo.SectorsPerCluster);
                    ulong extentLength = (ulong)(runLength * this.diskInfo.BytesPerSector * this.diskInfo.SectorsPerCluster);

                    if (offset >= extentVcn + extentLength)
                    {
                        continue;
                    }

                    if (offset > extentVcn)
                    {
                        extentLcn = extentLcn + offset - extentVcn;
                        extentLength = extentLength - (offset - extentVcn);
                        extentVcn = offset;
                    }

                    if (offset + wantedLength <= extentVcn)
                    {
                        continue;
                    }

                    if (offset + wantedLength < extentVcn + extentLength)
                    {
                        extentLength = offset + wantedLength - extentVcn;
                    }

                    if (extentLength == 0)
                    {
                        continue;
                    }

                    this.ReadFile(bufPtr + extentVcn - offset, extentLength, extentLcn);
                }
            }

            return buffer;
        }

        /// <summary>
        /// Process each attributes and gather information when necessary.
        /// </summary>
        private unsafe void ProcessAttributes(ref Node node, uint nodeIndex, byte* ptr, ulong bufLength, ushort instance, int depth, List<Stream> streams, bool isMftNode)
        {
            Attribute* attribute = null;
            for (uint attributeOffset = 0; attributeOffset < bufLength; attributeOffset = attributeOffset + attribute->Length)
            {
                attribute = (Attribute*)(ptr + attributeOffset);

                // exit the loop if end-marker.
                if ((attributeOffset + 4 <= bufLength) &&
                    (*(uint*)attribute == 0xFFFFFFFF))
                {
                    break;
                }

                // make sure we did read the data correctly
                if ((attributeOffset + 4 > bufLength) || attribute->Length < 3 ||
                    (attributeOffset + attribute->Length > bufLength))
                {
                    throw new Exception("Error: attribute in Inode %I64u is bigger than the data, the MFT may be corrupt.");
                }

                // attributes list needs to be processed at the end
                if (attribute->AttributeType == AttributeType.AttributeAttributeList)
                {
                    continue;
                }

                /* If the Instance does not equal the AttributeNumber then ignore the attribute.
                   This is used when an AttributeList is being processed and we only want a specific
                   instance. */
                if ((instance != 65535) && (instance != attribute->AttributeNumber))
                {
                    continue;
                }

                if (attribute->Nonresident == 0)
                {
                    ResidentAttribute* residentAttribute = (ResidentAttribute*)attribute;

                    switch (attribute->AttributeType)
                    {
                        case AttributeType.AttributeFileName:
                            AttributeFileName* attributeFileName = (AttributeFileName*)(ptr + attributeOffset + residentAttribute->ValueOffset);

                            if (attributeFileName->ParentDirectory.InodeNumberHighPart > 0)
                            {
                                throw new NotSupportedException("48 bits inode are not supported to reduce memory footprint.");
                            }

                            // node.ParentNodeIndex = ((UInt64)attributeFileName->ParentDirectory.InodeNumberHighPart << 32) + attributeFileName->ParentDirectory.InodeNumberLowPart;
                            node.ParentNodeIndex = attributeFileName->ParentDirectory.InodeNumberLowPart;

                            if (attributeFileName->NameType == 1 || node.NameIndex == 0)
                            {
                                node.NameIndex = this.GetNameIndex(new string(&attributeFileName->Name, 0, attributeFileName->NameLength));
                            }

                            break;

                        case AttributeType.AttributeStandardInformation:
                            AttributeStandardInformation* attributeStandardInformation = (AttributeStandardInformation*)(ptr + attributeOffset + residentAttribute->ValueOffset);

                            node.Attributes |= (Attributes)attributeStandardInformation->FileAttributes;

                            if ((this.retrieveMode & RetrieveMode.StandardInformations) == RetrieveMode.StandardInformations)
                            {
                                this.standardInformations[nodeIndex] =
                                    new StandardInformation(
                                        attributeStandardInformation->CreationTime,
                                        attributeStandardInformation->FileChangeTime,
                                        attributeStandardInformation->LastAccessTime);
                            }

                            break;

                        case AttributeType.AttributeData:
                            node.Size = residentAttribute->ValueLength;
                            break;
                    }
                }
                else
                {
                    NonResidentAttribute* nonResidentAttribute = (NonResidentAttribute*)attribute;

                    // save the length (number of bytes) of the data.
                    if (attribute->AttributeType == AttributeType.AttributeData && node.Size == 0)
                    {
                        node.Size = nonResidentAttribute->DataSize;
                    }

                    if (streams != null)
                    {
                        // extract the stream name
                        int streamNameIndex = 0;
                        if (attribute->NameLength > 0)
                        {
                            streamNameIndex = this.GetNameIndex(new string((char*)(ptr + attributeOffset + attribute->NameOffset), 0, (int)attribute->NameLength));
                        }

                        // find or create the stream
                        Stream stream =
                            this.SearchStream(streams, attribute->AttributeType, streamNameIndex);

                        if (stream == null)
                        {
                            stream = new Stream(streamNameIndex, attribute->AttributeType, nonResidentAttribute->DataSize);
                            streams.Add(stream);
                        }
                        else if (stream.Size == 0)
                        {
                            stream.Size = nonResidentAttribute->DataSize;
                        }

                        // we need the fragment of the MFTNode so retrieve them this time
                        // even if fragments aren't normally read
                        if (isMftNode || (this.retrieveMode & RetrieveMode.Fragments) == RetrieveMode.Fragments)
                        {
                            this.ProcessFragments(
                                ref node,
                                stream,
                                ptr + attributeOffset + nonResidentAttribute->RunArrayOffset,
                                attribute->Length - nonResidentAttribute->RunArrayOffset,
                                nonResidentAttribute->StartingVcn);
                        }
                    }
                }
            }

            if (streams != null && streams.Count > 0)
            {
                node.Size = streams[0].Size;
            }
        }

        /// <summary>
        /// Process fragments for streams.
        /// </summary>
        private unsafe void ProcessFragments(
            ref Node node,
            Stream stream,
            byte* runData,
            uint runDataLength,
            ulong startingVcn)
        {
            if (runData == null)
            {
                return;
            }

            /* Walk through the RunData and add the extents. */
            uint index = 0;
            long lcn = 0;
            long vcn = (long)startingVcn;
            int runOffsetSize = 0;
            int runLengthSize = 0;

            while (runData[index] != 0)
            {
                /* Decode the RunData and calculate the next Lcn. */
                runLengthSize = runData[index] & 0x0F;
                runOffsetSize = (runData[index] & 0xF0) >> 4;

                if (++index >= runDataLength)
                {
                    throw new Exception("Error: datarun is longer than buffer, the MFT may be corrupt.");
                }

                long runLength =
                    ProcessRunLength(runData, runDataLength, runLengthSize, ref index);

                long runOffset =
                    ProcessRunOffset(runData, runDataLength, runOffsetSize, ref index);

                lcn += runOffset;
                vcn += runLength;

                /* Add the size of the fragment to the total number of clusters.
                   There are two kinds of fragments: real and virtual. The latter do not
                   occupy clusters on disk, but are information used by compressed
                   and sparse files. */
                if (runOffset != 0)
                {
                    stream.Clusters += (ulong)runLength;
                }

                stream.Fragments.Add(
                    new Fragment(
                        runOffset == 0 ? VIRTUALFRAGMENT : (ulong)lcn,
                        (ulong)vcn));
            }
        }

        /// <summary>
        /// Process an actual MFT record from the buffer.
        /// </summary>
        private unsafe bool ProcessMftRecord(byte* buffer, ulong length, uint nodeIndex, out Node node, List<Stream> streams, bool isMftNode)
        {
            node = default(Node);

            FileRecordHeader* ntfsFileRecordHeader = (FileRecordHeader*)buffer;

            if (ntfsFileRecordHeader->RecordHeader.Type != RecordType.File)
            {
                return false;
            }

            ulong baseInode = ((ulong)ntfsFileRecordHeader->BaseFileRecord.InodeNumberHighPart << 32) + ntfsFileRecordHeader->BaseFileRecord.InodeNumberLowPart;

            // This is an inode extension used in an AttributeAttributeList of another inode, don't parse it
            if (baseInode != 0)
            {
                return false;
            }

            if (ntfsFileRecordHeader->AttributeOffset >= length)
            {
                throw new Exception("Error: attributes in Inode %I64u are outside the FILE record, the MFT may be corrupt.");
            }

            if (ntfsFileRecordHeader->BytesInUse > length)
            {
                throw new Exception("Error: in Inode %I64u the record is bigger than the size of the buffer, the MFT may be corrupt.");
            }

            if ((ntfsFileRecordHeader->Flags & 1) == 1)
            {
                //node.InUse = true;
            }
            else
            {
                //node.InUse = false;
                return false;
            }

            // make the file appear in the rootdirectory by default
            node.ParentNodeIndex = ROOTDIRECTORY;

            if ((ntfsFileRecordHeader->Flags & 2) == 2)
            {
                node.Attributes |= Attributes.Directory;
            }

            this.ProcessAttributes(ref node, nodeIndex, buffer + ntfsFileRecordHeader->AttributeOffset, length - ntfsFileRecordHeader->AttributeOffset, 65535, 0, streams, isMftNode);

            return true;
        }

        /// <summary>
        /// Begin the process of interpreting MFT data.
        /// </summary>
        private unsafe Node[] ProcessMft()
        {
            // 64 KB seems to be optimal for Windows XP, Vista is happier with 256KB...
            uint bufferSize =
                (Environment.OSVersion.Version.Major >= 6 ? 256u : 64u) * 1024;

            byte[] data = new byte[bufferSize];

            fixed (byte* buffer = data)
            {
                // Read the $MFT record from disk into memory, which is always the first record in the MFT.
                this.ReadFile(buffer, this.diskInfo.BytesPerMftRecord, this.diskInfo.MftStartLcn * this.diskInfo.BytesPerSector * this.diskInfo.SectorsPerCluster);

                // Fixup the raw data from disk. This will also test if it's a valid $MFT record.
                this.FixupRawMftdata(buffer, this.diskInfo.BytesPerMftRecord);

                List<Stream> mftStreams = new List<Stream>();

                if ((this.retrieveMode & RetrieveMode.StandardInformations) == RetrieveMode.StandardInformations)
                {
                    this.standardInformations = new StandardInformation[1]; // allocate some space for $MFT record
                }

                Node mftNode;
                if (!this.ProcessMftRecord(buffer, this.diskInfo.BytesPerMftRecord, 0, out mftNode, mftStreams, true))
                {
                    throw new Exception("Can't interpret Mft Record");
                }

                Stream dataStream = this.SearchStream(mftStreams, AttributeType.AttributeData);
                uint maxInode = (uint)(dataStream.Size / this.diskInfo.BytesPerMftRecord);
                Node[] nodes = new Node[maxInode];
                nodes[0] = mftNode;

                if ((this.retrieveMode & RetrieveMode.StandardInformations) == RetrieveMode.StandardInformations)
                {
                    StandardInformation mftRecordInformation = this.standardInformations[0];
                    this.standardInformations = new StandardInformation[maxInode];
                    this.standardInformations[0] = mftRecordInformation;
                }

                if ((this.retrieveMode & RetrieveMode.Streams) == RetrieveMode.Streams)
                {
                    this.streams = new Stream[maxInode][];
                }

                /* Read and process all the records in the MFT. The records are read into a
                   buffer and then given one by one to the InterpretMftRecord() subroutine. */

                ulong blockStart = 0, blockEnd = 0;
                ulong realVcn = 0, vcn = 0;

                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();

                ulong totalBytesRead = 0;
                int fragmentIndex = 0;
                int fragmentCount = dataStream.Fragments.Count;
                for (uint nodeIndex = 1; nodeIndex < maxInode; nodeIndex++)
                {
                    if (nodeIndex >= blockEnd)
                    {
                        if (!this.ReadNextChunk(
                                buffer,
                                bufferSize,
                                nodeIndex,
                                fragmentIndex,
                                dataStream,
                                ref blockStart,
                                ref blockEnd,
                                ref vcn,
                                ref realVcn))
                        {
                            break;
                        }

                        totalBytesRead += (blockEnd - blockStart) * this.diskInfo.BytesPerMftRecord;
                    }

                    this.FixupRawMftdata(
                            buffer + ((nodeIndex - blockStart) * this.diskInfo.BytesPerMftRecord),
                            this.diskInfo.BytesPerMftRecord);

                    List<Stream> streams = null;
                    if ((this.retrieveMode & RetrieveMode.Streams) == RetrieveMode.Streams)
                    {
                        streams = new List<Stream>();
                    }

                    Node newNode;
                    if (!this.ProcessMftRecord(
                            buffer + ((nodeIndex - blockStart) * this.diskInfo.BytesPerMftRecord),
                            this.diskInfo.BytesPerMftRecord,
                            nodeIndex,
                            out newNode,
                            streams,
                            false))
                    {
                        continue;
                    }

                    nodes[nodeIndex] = newNode;

                    if (streams != null)
                    {
                        this.streams[nodeIndex] = streams.ToArray();
                    }

                    if (EnumExtensions.HasFlag(newNode.Attributes, Attributes.Directory))
                    {
                        if (this.parentNodeSubFolderCount.Contains(newNode.ParentNodeIndex))
                        {
                            this.parentNodeSubFolderCount[newNode.ParentNodeIndex] = (ulong)this.parentNodeSubFolderCount[newNode.ParentNodeIndex] + 1;
                        }
                        else
                        {
                            this.parentNodeSubFolderCount.Add(newNode.ParentNodeIndex, 1UL);
                        }
                    }
                    else
                    {
                        if (this.parentNodeSubFileCount.Contains(newNode.ParentNodeIndex))
                        {
                            this.parentNodeSubFileCount[newNode.ParentNodeIndex] = (ulong)this.parentNodeSubFileCount[newNode.ParentNodeIndex] + 1;
                        }
                        else
                        {
                            this.parentNodeSubFileCount.Add(newNode.ParentNodeIndex, 1UL);
                        }

                        if (this.parentNodeSubFileTotalSize.Contains(newNode.ParentNodeIndex))
                        {
                            this.parentNodeSubFileTotalSize[newNode.ParentNodeIndex] = (ulong)this.parentNodeSubFileTotalSize[newNode.ParentNodeIndex] + newNode.Size;
                        }
                        else
                        {
                            this.parentNodeSubFileTotalSize.Add(newNode.ParentNodeIndex, newNode.Size);
                        }
                    }

                    // Reclaim some memory after every 50,000th iteration
                    /*
                    if (nodeIndex % 50000 == 0)
                    {
                        GC.Collect();
                    }
                    */
                }

                stopwatch.Stop();

                Trace.WriteLine(
                    string.Format(
                        "{0:F3} MB of volume metadata has been read in {1:F3} s at {2:F3} MB/s",
                        (float)totalBytesRead / (1024 * 1024),
                        (float)stopwatch.Elapsed.TotalSeconds,
                        (float)totalBytesRead / (1024 * 1024) / stopwatch.Elapsed.TotalSeconds));

                return nodes;
            }
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private unsafe struct BootSector
        {
            public fixed byte AlignmentOrReserved1[3];
            public ulong Signature;
            public ushort BytesPerSector;
            public byte SectorsPerCluster;
            public fixed byte AlignmentOrReserved2[26];
            public ulong TotalSectors;
            public ulong MftStartLcn;
            public ulong Mft2StartLcn;
            public uint ClustersPerMftRecord;
            public uint ClustersPerIndexRecord;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct VolumeData
        {
            public ulong VolumeSerialNumber;
            public ulong NumberSectors;
            public ulong TotalClusters;
            public ulong FreeClusters;
            public ulong TotalReserved;
            public uint BytesPerSector;
            public uint BytesPerCluster;
            public uint BytesPerFileRecordSegment;
            public uint ClustersPerFileRecordSegment;
            public ulong MftValidDataLength;
            public ulong MftStartLcn;
            public ulong Mft2StartLcn;
            public ulong MftZoneStart;
            public ulong MftZoneEnd;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct RecordHeader
        {
            public RecordType Type;                  /* File type, for example 'FILE' */
            public ushort UsaOffset;             /* Offset to the Update Sequence Array */
            public ushort UsaCount;              /* Size in words of Update Sequence Array */
            public ulong Lsn;                   /* $LogFile Sequence Number (LSN) */
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct INodeReference
        {
            public uint InodeNumberLowPart;
            public ushort InodeNumberHighPart;
            public ushort SequenceNumber;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct FileRecordHeader
        {
            public RecordHeader RecordHeader;
            public ushort SequenceNumber;        /* Sequence number */
            public ushort LinkCount;             /* Hard link count */
            public ushort AttributeOffset;       /* Offset to the first Attribute */
            public ushort Flags;                 /* Flags. bit 1 = in use, bit 2 = directory, bit 4 & 8 = unknown. */
            public uint BytesInUse;             /* Real size of the FILE record */
            public uint BytesAllocated;         /* Allocated size of the FILE record */
            public INodeReference BaseFileRecord;     /* File reference to the base FILE record */
            public ushort NextAttributeNumber;   /* Next Attribute Id */
            public ushort Padding;               /* Align to 4 UCHAR boundary (XP) */
            public uint MFTRecordNumber;        /* Number of this MFT Record (XP) */
            public ushort UpdateSeqNum;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct Attribute
        {
            public AttributeType AttributeType;
            public uint Length;
            public byte Nonresident;
            public byte NameLength;
            public ushort NameOffset;
            public ushort Flags;              /* 0x0001 = Compressed, 0x4000 = Encrypted, 0x8000 = Sparse */
            public ushort AttributeNumber;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private unsafe struct AttributeList
        {
            public AttributeType AttributeType;
            public ushort Length;
            public byte NameLength;
            public byte NameOffset;
            public ulong LowestVcn;
            public INodeReference FileReferenceNumber;
            public ushort Instance;
            public fixed ushort AlignmentOrReserved[3];
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct AttributeFileName
        {
            public INodeReference ParentDirectory;
            public ulong CreationTime;
            public ulong ChangeTime;
            public ulong LastWriteTime;
            public ulong LastAccessTime;
            public ulong AllocatedSize;
            public ulong DataSize;
            public uint FileAttributes;
            public uint AlignmentOrReserved;
            public byte NameLength;
            public byte NameType;                 /* NTFS=0x01, DOS=0x02 */
            public char Name;
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct AttributeStandardInformation
        {
            public ulong CreationTime;
            public ulong FileChangeTime;
            public ulong MftChangeTime;
            public ulong LastAccessTime;
            public uint FileAttributes;       /* READ_ONLY=0x01, HIDDEN=0x02, SYSTEM=0x04, VOLUME_ID=0x08, ARCHIVE=0x20, DEVICE=0x40 */
            public uint MaximumVersions;
            public uint VersionNumber;
            public uint ClassId;
            public uint OwnerId;                        // NTFS 3.0 only
            public uint SecurityId;                     // NTFS 3.0 only
            public ulong QuotaCharge;                // NTFS 3.0 only
            public ulong Usn;                              // NTFS 3.0 only
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct ResidentAttribute
        {
            public Attribute Attribute;
            public uint ValueLength;
            public ushort ValueOffset;
            public ushort Flags;               // 0x0001 = Indexed
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private unsafe struct NonResidentAttribute
        {
            public Attribute Attribute;
            public ulong StartingVcn;
            public ulong LastVcn;
            public ushort RunArrayOffset;
            public byte CompressionUnit;
            public fixed byte AlignmentOrReserved[5];
            public ulong AllocatedSize;
            public ulong DataSize;
            public ulong InitializedSize;
            public ulong CompressedSize;    // Only when compressed
        }

        [StructLayout(LayoutKind.Sequential, Pack = 1)]
        private struct Fragment
        {
            public ulong Lcn;                // Logical cluster number, location on disk.
            public ulong NextVcn;            // Virtual cluster number of next fragment.

            public Fragment(ulong lcn, ulong nextVcn)
            {
                this.Lcn = lcn;
                this.NextVcn = nextVcn;
            }
        }

        /// <summary>
        /// Node struct for file and directory entries.
        /// </summary>
        /// <remarks>
        /// We keep this as small as possible to reduce footprint for large volume.
        /// </remarks>
        private struct Node
        {
            public Attributes Attributes;
            //public bool InUse;
            public uint ParentNodeIndex;
            public ulong Size;
            public ulong SubFileTotalSize;
            public int NameIndex;
        }

        /// <summary>
        /// Contains extra information not required for basic purposes.
        /// </summary>
        private struct StandardInformation
        {
            public ulong CreationTime;
            public ulong LastAccessTime;
            public ulong LastChangeTime;

            public StandardInformation(
                ulong creationTime,
                ulong lastAccessTime,
                ulong lastChangeTime)
            {
                this.CreationTime = creationTime;
                this.LastAccessTime = lastAccessTime;
                this.LastChangeTime = lastChangeTime;
            }
        }

        private sealed class Stream
        {
            public ulong Clusters;                      // Total number of clusters.
            public ulong Size;                          // Total number of bytes.
            public AttributeType Type;
            public int NameIndex;
            public List<Fragment> FragmentsList;

            public Stream(int nameIndex, AttributeType type, ulong size)
            {
                this.NameIndex = nameIndex;
                this.Type = type;
                this.Size = size;
            }

            public List<Fragment> Fragments
            {
                get
                {
                    if (this.FragmentsList == null)
                    {
                        this.FragmentsList = new List<Fragment>(5);
                    }

                    return this.FragmentsList;
                }
            }
        }

        /// <summary>
        /// Add some functionality to the basic stream.
        /// </summary>
        private sealed class FragmentWrapper : IFragment
        {
            private StreamWrapper owner;
            private Fragment fragment;

            public FragmentWrapper(StreamWrapper owner, Fragment fragment)
            {
                this.owner = owner;
                this.fragment = fragment;
            }

            public ulong Lcn
            {
                get { return this.fragment.Lcn; }
            }

            public ulong NextVcn
            {
                get { return this.fragment.NextVcn; }
            }
        }

        /// <summary>
        /// Add some functionality to the basic stream.
        /// </summary>
        private sealed class StreamWrapper : IStream
        {
            private NtfsReader reader;
            private NodeWrapper parentNode;
            private int streamIndex;

            public StreamWrapper(NtfsReader reader, NodeWrapper parentNode, int streamIndex)
            {
                this.reader = reader;
                this.parentNode = parentNode;
                this.streamIndex = streamIndex;
            }

            public string Name
            {
                get
                {
                    return this.reader.GetNameFromIndex(this.reader.streams[this.parentNode.NodeIndex][this.streamIndex].NameIndex);
                }
            }

            public ulong Size
            {
                get
                {
                    return this.reader.streams[this.parentNode.NodeIndex][this.streamIndex].Size;
                }
            }

            public IList<IFragment> Fragments
            {
                get
                {
                    // if ((_reader._retrieveMode & RetrieveMode.Fragments) != RetrieveMode.Fragments)
                    //    throw new NotSupportedException("The fragments haven't been retrieved. Make sure to use the proper RetrieveMode.");
                    IList<Fragment> fragments = this.reader.streams[this.parentNode.NodeIndex][this.streamIndex].Fragments;

                    if (fragments == null || fragments.Count == 0)
                    {
                        return null;
                    }

                    List<IFragment> newFragments = new List<IFragment>();
                    foreach (Fragment fragment in fragments)
                    {
                        newFragments.Add(new FragmentWrapper(this, fragment));
                    }

                    return newFragments;
                }
            }
        }

        /// <summary>
        /// Add some functionality to the basic node.
        /// </summary>
        private sealed class NodeWrapper : INode
        {
            private NtfsReader reader;
            private uint nodeIndex;
            private Node node;
            private bool isDirectory;
            private ulong? subFolderCount;
            private ulong? subFileCount;
            private ulong? subFileTotalSize;
            private string fullName;

            public NodeWrapper(NtfsReader reader, uint nodeIndex, Node node)
            {
                this.reader = reader;
                this.nodeIndex = nodeIndex;
                this.node = node;
            }

            public uint NodeIndex
            {
                get { return this.nodeIndex; }
            }

            //public bool InUse
            //{
            //    get { return this.node.InUse; }
            //}

            public uint ParentNodeIndex
            {
                get { return this.node.ParentNodeIndex; }
            }

            public Attributes Attributes
            {
                get { return this.node.Attributes; }
            }

            public string Name
            {
                get { return this.reader.GetNameFromIndex(this.node.NameIndex); }
            }

            public ulong Size
            {
                get { return this.node.Size; }
            }

            public string FullName
            {
                get
                {
                    if (this.fullName == null)
                    {
                        this.fullName = this.reader.GetNodeFullNameCore(this.nodeIndex);
                    }

                    return this.fullName;
                }
            }

            public bool Directory
            {
                get
                {
                    if (EnumExtensions.HasFlag(this.node.Attributes, Attributes.Directory))
                    {
                        return true;
                    }

                    return false;
                }
            }

            public ulong? SubFolderCount
            {
                get
                {
                    if (!EnumExtensions.HasFlag(this.node.Attributes, Attributes.Directory))
                    {
                        return null;
                    }

                    this.subFolderCount = this.reader.GetSubFolderCount(this.nodeIndex);

                    return this.subFolderCount;
                }
            }

            public ulong? SubFileCount
            {
                get
                {
                    if (!EnumExtensions.HasFlag(this.node.Attributes, Attributes.Directory))
                    {
                        return null;
                    }

                    this.subFileCount = this.reader.GetSubFileCount(this.nodeIndex);

                    return this.subFileCount;
                }
            }

            public ulong? SubFileTotalSize
            {
                get
                {
                    if (!EnumExtensions.HasFlag(this.node.Attributes, Attributes.Directory))
                    {
                        return null;
                    }

                    this.subFileTotalSize = this.reader.GetSubFileTotalSize(this.nodeIndex);

                    return this.subFileTotalSize;
                }
            }

            public IList<IStream> Streams
            {
                get
                {
                    if (this.reader.streams == null)
                    {
                        throw new NotSupportedException("The streams haven't been retrieved. Make sure to use the proper RetrieveMode.");
                    }

                    Stream[] streams = this.reader.streams[this.nodeIndex];
                    if (streams == null)
                    {
                        return null;
                    }

                    List<IStream> newStreams = new List<IStream>();
                    for (int i = 0; i < streams.Length; ++i)
                    {
                        newStreams.Add(new StreamWrapper(this.reader, this, i));
                    }

                    return newStreams;
                }
            }

            public DateTime CreationTime
            {
                get
                {
                    if (this.reader.standardInformations == null)
                    {
                        throw new NotSupportedException("The StandardInformation haven't been retrieved. Make sure to use the proper RetrieveMode.");
                    }

                    return DateTime.FromFileTimeUtc((long)this.reader.standardInformations[this.nodeIndex].CreationTime);
                }
            }

            public DateTime LastChangeTime
            {
                get
                {
                    if (this.reader.standardInformations == null)
                    {
                        throw new NotSupportedException("The StandardInformation haven't been retrieved. Make sure to use the proper RetrieveMode.");
                    }

                    return DateTime.FromFileTimeUtc((long)this.reader.standardInformations[this.nodeIndex].LastChangeTime);
                }
            }

            public DateTime LastAccessTime
            {
                get
                {
                    if (this.reader.standardInformations == null)
                    {
                        throw new NotSupportedException("The StandardInformation haven't been retrieved. Make sure to use the proper RetrieveMode.");
                    }

                    return DateTime.FromFileTimeUtc((long)this.reader.standardInformations[this.nodeIndex].LastAccessTime);
                }
            }
        }

        /// <summary>
        /// Simple structure of available disk informations.
        /// </summary>
        private sealed class DiskInfoWrapper : IDiskInfo
        {
            public ushort BytesPerSector;
            public byte SectorsPerCluster;
            public ulong TotalSectors;
            public ulong MftStartLcn;
            public ulong Mft2StartLcn;
            public uint ClustersPerMftRecord;
            public uint ClustersPerIndexRecord;
            public ulong BytesPerMftRecord;
            public ulong BytesPerCluster;
            public ulong TotalClusters;

            ushort IDiskInfo.BytesPerSector
            {
                get { return this.BytesPerSector; }
            }

            byte IDiskInfo.SectorsPerCluster
            {
                get { return this.SectorsPerCluster; }
            }

            ulong IDiskInfo.TotalSectors
            {
                get { return this.TotalSectors; }
            }

            ulong IDiskInfo.MftStartLcn
            {
                get { return this.MftStartLcn; }
            }

            ulong IDiskInfo.Mft2StartLcn
            {
                get { return this.Mft2StartLcn; }
            }

            uint IDiskInfo.ClustersPerMftRecord
            {
                get { return this.ClustersPerMftRecord; }
            }

            uint IDiskInfo.ClustersPerIndexRecord
            {
                get { return this.ClustersPerIndexRecord; }
            }

            ulong IDiskInfo.BytesPerMftRecord
            {
                get { return this.BytesPerMftRecord; }
            }

            ulong IDiskInfo.BytesPerCluster
            {
                get { return this.BytesPerCluster; }
            }

            ulong IDiskInfo.TotalClusters
            {
                get { return this.TotalClusters; }
            }
        }
    }
}
