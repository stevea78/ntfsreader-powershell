﻿/*
    The NtfsReader library.

    Copyright (C) 2008 Danny Couture

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA

    For the full text of the license see the "License.txt" file.

    This library is based on the work of Jeroen Kessels, Author of JkDefrag.
    http://www.kessels.com/Jkdefrag/

    Special thanks goes to him.

    Danny Couture
    Software Architect
*/
using System.Collections.Generic;
using System.Text;

namespace System.IO.Filesystem.Ntfs
{
    public static class EnumExtensions
    {
        /// <summary>
        /// A FX 3.5 way to mimic the FX4 "HasFlag" method.
        /// </summary>
        /// <param name="variable">The tested enum.</param>
        /// <param name="value">The value to test.</param>
        /// <returns>True if the flag is set. Otherwise false.</returns>
        public static bool HasFlag(Enum variable, Enum value)
        {
            // check if from the same type.
            if (variable.GetType() != value.GetType())
            {
                throw new ArgumentException("The checked flag is not from the same type as the checked variable.");
            }

            Convert.ToUInt64(value);
            ulong num = Convert.ToUInt64(value);
            ulong num2 = Convert.ToUInt64(variable);

            return (num2 & num) == num;
        }
    }

    public partial class NtfsReader
    {
        /// <summary>
        /// Recurse the node hierarchy and construct its entire name
        /// stopping at the root directory.
        /// </summary>
        private string GetNodeFullNameCore(uint nodeIndex)
        {
            uint node = nodeIndex;

            Stack<uint> fullPathNodes = new Stack<uint>();
            fullPathNodes.Push(node);

            uint lastNode = node;
            while (true)
            {
                uint parent = this.nodes[node].ParentNodeIndex;

                // loop until we reach the root directory
                if (parent == ROOTDIRECTORY)
                {
                    break;
                }

                if (parent == lastNode)
                {
                    throw new InvalidDataException("Detected a loop in the tree structure.");
                }

                fullPathNodes.Push(parent);

                lastNode = node;
                node = parent;
            }

            StringBuilder fullPath = new StringBuilder();
            fullPath.Append(this.driveInfo.Name.TrimEnd(new char[] { '\\' }));

            while (fullPathNodes.Count > 0)
            {
                node = fullPathNodes.Pop();

                fullPath.Append(@"\");
                fullPath.Append(this.GetNameFromIndex(this.nodes[node].NameIndex));
            }

            return fullPath.ToString();
        }

        private ulong? GetSubFolderCount(uint nodeIndex)
        {
            if (!EnumExtensions.HasFlag(this.nodes[nodeIndex].Attributes, Attributes.Directory))
            {
                return null;
            }

            if (this.parentNodeSubFolderCount.Contains(nodeIndex))
            {
                return (ulong)this.parentNodeSubFolderCount[nodeIndex];
            }
            else
            {
                return 0UL;
            }
        }

        private ulong? GetSubFileCount(uint nodeIndex)
        {
            if (!EnumExtensions.HasFlag(this.nodes[nodeIndex].Attributes, Attributes.Directory))
            {
                return null;
            }

            if (this.parentNodeSubFileCount.Contains(nodeIndex))
            {
                return (ulong)this.parentNodeSubFileCount[nodeIndex];
            }
            else
            {
                return 0UL;
            }
        }

        private ulong? GetSubFileTotalSize(uint nodeIndex)
        {
            if (!EnumExtensions.HasFlag(this.nodes[nodeIndex].Attributes, Attributes.Directory))
            {
                return null;
            }

            if (this.parentNodeSubFileTotalSize.Contains(nodeIndex))
            {
                return (ulong)this.parentNodeSubFileTotalSize[nodeIndex];
            }
            else
            {
                return 0UL;
            }
        }
    }
}
